#!/usr/bin/env python3
import main
from main import connection
import cgi
import html

# Запись изображений в файл
def write_file(data, filename):
   with open(filename, 'wb') as f:
       f.write(data)

form = cgi.FieldStorage()
info = form.getfirst("info", "постое значение")

info = html.escape(info)
print("Content-Type: text/html")  # Добавлен заголовок Content-Type для указания типа содержимого

print("""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Информация о клиентах</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Список клиентов</h1>
    <table>
        <tr>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Адрес</th>
            <th>Телефон</th>
        </tr>
""")

try:
    with connection.cursor() as cursor:
        select_clients = "SELECT * FROM `Client`"
        cursor.execute(select_clients)
        clients = cursor.fetchall()

        for client in clients:
            ferst_name = html.escape(client['ferst_name'])  # Исправлена опечатка в названии поля
            last_name = html.escape(client['last_name'])
            address = html.escape(client['address'])
            phone = html.escape(client['phone'])

            print("<tr>")
            print(f"<td>{ferst_name}</td>")
            print(f"<td>{last_name}</td>")
            print(f"<td>{address}</td>")
            print(f"<td>{phone}</td>")
            print("</tr>")
finally:
    connection.close()

print("""
       </table>
   </body>
   </html>
""")
