host = 'localhost'
user ='root'
password = ''
db_name = 'bank'