from flask import Flask, render_template
from main import connection
import main
from main import connection
import cgi
import html


app = Flask(__name__)

@app.route('/')
def index():
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM `Client`")
            clients = cursor.fetchall()
            return render_template('index.html', clients=clients)
    finally:
        connection.close()

if __name__ == '__main__':
    app.run()

