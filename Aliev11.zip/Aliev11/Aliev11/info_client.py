from main import connection

try:
    with connection.cursor() as cursor:
        while True:
            info_client = input("Если вам нужна информация о клиентах, нажмите 1: ")
            if info_client == "1":
                cursor.execute("SELECT * FROM `Client`")
                clients = cursor.fetchall()
                for client in clients:
                    print(f"Имя: {client[3]}, Фамилия: {client[4]}, Адрес: {client[5]}, Телефон: {client[6]}")
                client_name = input("Введите имя клиента, чтобы узнать сумму его займа: ")
                cursor.execute("SELECT * FROM `Client` WHERE `last_name` = %s", (client_name,))
                client = cursor.fetchone()

                if client:
                    cursor.execute("SELECT * FROM `loan` WHERE `id_client` = %s", (client[1],))
                    loan_info = cursor.fetchall()
                    if loan_info:
                        for loan in loan_info:
                            print(f"Имя: {client[3]}, Фамилия: {client[4]}, Сумма займа: {loan[2]}")

                            # Вызов хранимой процедуры calculate_loan_payment
                            cursor.execute("CALL calculateLoan(%s)", (loan[0],))

                            # Получение результатов хранимой процедуры
                            results = cursor.fetchall()
                            for result in results:
                                print(f"Ежемесячный платеж: {result[0]}, Сумма переплаты за период: {result[1]}")
                    else:
                        print("Для данного клиента нет информации о займах.")
                else:
                    print("Клиент не найден.")
                break
            else:
                print("Неверный выбор. Попробуйте еще раз.")

finally:
    connection.close()
