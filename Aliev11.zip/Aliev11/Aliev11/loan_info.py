#!/usr/bin/env python3
import main
from main  import connection
import config
import cgi
import html

def write_file(data, filename):
   with open(filename, 'wb') as f:
       f.write(data)

try:
    with connection.cursor() as cursor:
        # Получение списка клиентов
        select_clients = "SELECT * FROM `Client`"
        cursor.execute(select_clients)
        clients = cursor.fetchall()

        print("<table>")
        print("<tr>")
        print("<th>Имя</th>")
        print("<th>Фамилия</th>")
        print("<th>Адрес</th>")
        print("<th>Телефон</th>")
        print("</tr>")

        for client in clients:
            ferst_name = html.escape(client['ferst_name'])
            last_name = html.escape(client['last_name'])
            address = html.escape(client['address'])
            phone = html.escape(client['phone'])

            print("<tr>")
            print(f"<td>{ferst_name}</td>")
            print(f"<td>{last_name}</td>")
            print(f"<td>{address}</td>")
            print(f"<td>{phone}</td>")
            print("</tr>")

        print("</table>")
finally:
    connection.close()
