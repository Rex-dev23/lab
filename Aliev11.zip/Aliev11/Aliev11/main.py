import  pymysql
from config import host,user,password,db_name

try:
    connection = pymysql.connect(
        host= host,
        user=user,
        password = password,
        database=db_name
    )
    print('Подключенно')
    print('#' *20 )

except Exception as ex:
    print('Not connect')
    print(ex)